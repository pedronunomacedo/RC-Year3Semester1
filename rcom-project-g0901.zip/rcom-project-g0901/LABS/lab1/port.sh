socat -d -d pty,raw,echo=0 pty,raw,echo=0

echo "Serial port established!\n"