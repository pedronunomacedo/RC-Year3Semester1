// Application layer protocol implementation

#include "../include/application_layer.h"
#define BUF_SIZE 256
#define BUF_SIZE2 400

int prepareControlPacket(unsigned char *controlPacket, int bufSize, char C, int fileSize, const char *filename) {
    controlPacket[0] = C;
    controlPacket[1] = 0;

    unsigned char len; // this will be used to hold strlens
    char sizeStr[10];
    sprintf(sizeStr, "%d", fileSize); // stores the size of the file in a string
    unsigned char length = strlen(sizeStr); // Stores the length of the sizeStr variable

    len = strlen(sizeStr); // Size of the sizeStr variable

    controlPacket[2] = len;

    memcpy(controlPacket + 3, sizeStr, len); // (controlPacket + 3) is positioned on the first byte of the V1 field

    unsigned int currentPos=3+len; // Position the head of the array in the T2 field

    controlPacket[currentPos] = 1; // Indicates the V2 field contains the name of the file
    currentPos++; // Position the head of the array in the L2 field
    
    len = strlen(filename); // Size of the variable filename
    controlPacket[currentPos] = len; // Indicates the size of the variable to be read in the V2 field
    currentPos++; // Position the head of the array in the first byte of the V2 field
    memcpy(controlPacket+currentPos, filename, len);

    currentPos += len; // Corresponds to the size of the controlPacket array

    return currentPos; // Goes to llwrite!
}

int prepareDataPacket(unsigned char *dataBytes, unsigned char *dataControlPacket, int numSequence, int numBytes) {
    dataControlPacket[0] = 0x01;
    dataControlPacket[1] = numSequence;
    dataControlPacket[2] = numBytes / 255;
    dataControlPacket[3] = numBytes % 255;

    memcpy(dataControlPacket + 4, &dataBytes, sizeof(dataBytes));

    return (numBytes + 4);
}


void applicationLayer(const char *serialPort, const char *role, int baudRate,
                      int nTries, int timeout, const char *filename) {
    // Emissor
    // printf("%s\n",role);
    int resTx = strcmp(role,"tx");
    // printf("%d\n",resTx);
    int resRx = strcmp(role,"rx");
    // printf("%d\n",resRx);
    LinkLayer defs;
    strcpy(defs.serialPort, serialPort);
    if(resTx == 0){
        defs.role = LlTx; // TRANSMITTER
    } else if(resRx == 0) {
        defs.role = LlRx; // RECEIVER
    } else {
        printf("ERROR: Invalid role!\n");
        return;
    }
    defs.baudRate = baudRate;
    defs.nRetransmissions = nTries;
    defs.timeout = timeout;

    printf("\n\n-------------  Phase 1 : Establish connection --------------------\n\n");

    // Open the connection between the 2 devices and prepare to send and receive
    if (llopen(defs) < 0) {
        printf("ERROR: Couldn't receive UA from receiver!\n");
        return;
    }

    printf("\n(Connection established successfully)\n");



    printf("\n\n-------------  Phase 2 : Start reading the penguim file --------------------\n\n");

    unsigned char controlPacket[600];
    struct stat st;
    stat(filename, &st);
    int fileSize = st.st_size;
    int start = 0;

    if (resTx == 0) {
        // 1. Create controlPacket -> DONE
        // 2. Call the llwrite to create the info frame -> DONE
        // 2. Make byte stuffing on the array -> DONE
        // 3. Send the information frame to the receiver -> DONE
        int controlPacketSize = prepareControlPacket(controlPacket, BUF_SIZE, 2, fileSize, filename);
       
        if (llwrite(controlPacket, controlPacketSize) != 0) {
            printf("ERROR: llwrite() failed!\n");
            return;
        }

        unsigned char dataPacket[BUF_SIZE], dataBytes[BUF_SIZE], fileOver = FALSE;
        int dataPacketSize = 0;

        FILE* filePtr;

        int numSequence = 0, index = 0, packetSize = 100;

        filePtr = fopen(filename, "rb");
        if (filePtr == NULL) {
            printf("ERROR: Failed to read from file with name '%s'\n", filename);
            return;
        }

        // Start reading the file

        int totalBytesRead = 0;
        int numBytesRead = 0;
        while ((numBytesRead = fread(&dataBytes, (size_t) 1, (size_t) 100, filePtr)) > 0) {
            // create data packet
            printf("packetSize: %d\n", packetSize);
            int dataPacketSize = prepareDataPacket(dataBytes, &dataPacket, numSequence++, packetSize);
            printf("dataPacketSize = %d\n", dataPacketSize); // DELETE
            if (llwrite(dataPacket, dataPacketSize) < 0) { // PRESO AQUI!
                printf("ERROR: Failed to write data packet to llwrite!\n");
                return;
            }
            printf("aqui!\n");
            totalBytesRead += numBytesRead;
        }

        // Create data control END

        fclose(filePtr);
    }
    else if (resRx == 0) {
        // 1. Read the information frame -> DONE
        // 2. Send the response (RR or REJ) to the transmitter -> REVIEW!!!
        // unsigned char *readedInformationFrame;
        // int STOP = FALSE;
        // while (STOP == FALSE) {
        //     int res = llread(readedInformationFrame);
        //     if (res == -1) {
        //         printf("ERROR: llread() failed!\n");
        //     }
        //     else if (res == -2) {
        //         printf("REJ sent!\n");
        //         STOP = FALSE;
        //     }
        //     else if (res > 0) {
        //         STOP = TRUE;
        //     }
        // }
        
        unsigned char* readInformation[BUF_SIZE2];

        FILE* fileCreating = fopen(filename, "wb");

        for (int i = 0; i < 27; i++) {
            int bytesread = llread(readInformation);

            fwrite(readInformation, sizeof(unsigned char), sizeof(readInformation), fileCreating);
        }

        fclose(fileCreating);
    }
    else {
        printf("ERROR: Invalid role!\n");
        exit(1);
    }
}
