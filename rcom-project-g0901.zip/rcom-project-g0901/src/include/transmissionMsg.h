#pragma once

#include <stdio.h>
#include <string.h>

#define FALSE 0
#define TRUE 1

